import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { MapContainer, TileLayer, Marker, Popup, CircleMarker } from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import {
  ResponsiveContainer,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  Cell,
  CartesianGrid,
  Legend,
} from 'recharts';
import {
  Layers,
  RefreshCw,
  CheckCircle2,
  MapPin,
  Tag,
  User,
  Search,
  Loader2,
  Radio,
  FileText,
  Sparkles,
  Flame,
  Activity,
  Filter,
  Trash2,
  HelpCircle,
  Zap,
  Building2,
  AlertTriangle,
  TrendingUp,
  AlertCircle,
  Clock,
  ShieldAlert,
  Info,
  BarChart3,
} from 'lucide-react';
import { PageHeader } from '../../components/common/PageHeader';
import { Button } from '../../components/ui/Button';
import { Badge } from '../../components/ui/Badge';
import { Input } from '../../components/ui/Input';
import { ISSUE_CATEGORIES, MUNICIPAL_DEPARTMENTS } from '../../utils/constants';
import { calculateUrbanImpactScore, getRecommendedDepartment } from '../../utils/helpers';
import { supabase } from '../../services/supabaseClient';
import { issueService } from '../../services/issueService';
import { slaService } from '../../services/slaService';
import { useToast } from '../../hooks/useToast';
import { useTheme } from '../../hooks/useTheme';
import { useHotspots } from '../../hooks/useHotspots';
import { HotspotDetailsModal } from '../../components/hotspots/HotspotDetailsModal';
import { HotspotPriorityQueue } from '../../components/hotspots/HotspotPriorityQueue';

// Helper to create glowing tactical map marker icons based on severity/status
const createMarkerIcon = (severity, status) => {
  let color = '#3b82f6';
  let glow = 'rgba(59, 130, 246, 0.6)';

  if ((status || '').toLowerCase() === 'resolved') {
    color = '#10b981';
    glow = 'rgba(16, 185, 129, 0.6)';
  } else {
    switch ((severity || '').toLowerCase()) {
      case 'critical':
        color = '#ef4444';
        glow = 'rgba(239, 68, 68, 0.9)';
        break;
      case 'high':
        color = '#f97316';
        glow = 'rgba(249, 115, 22, 0.8)';
        break;
      case 'medium':
        color = '#eab308';
        glow = 'rgba(234, 179, 8, 0.7)';
        break;
      case 'low':
      default:
        color = '#10b981';
        glow = 'rgba(16, 185, 129, 0.6)';
        break;
    }
  }

  return L.divIcon({
    className: 'tactical-map-pin',
    html: `
      <div style="
        position: relative;
        width: 22px;
        height: 22px;
        background-color: ${color};
        border: 2px solid #ffffff;
        border-radius: 50%;
        box-shadow: 0 0 14px ${glow};
        display: flex;
        align-items: center;
        justify-content: center;
      ">
        <div style="width: 7px; height: 7px; background-color: #ffffff; border-radius: 50%;"></div>
      </div>
    `,
    iconSize: [22, 22],
    iconAnchor: [11, 11],
    popupAnchor: [0, -11],
  });
};

const CHART_COLORS = ['#3b82f6', '#f59e0b', '#10b981', '#ef4444', '#8b5cf6', '#ec4899', '#06b6d4'];

export function AdminPage() {
  const toast = useToast();
  const { theme } = useTheme();

  const [complaints, setComplaints] = useState([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState('all');
  const [severityFilter, setSeverityFilter] = useState('all');
  const [categoryFilter, setCategoryFilter] = useState('all');
  const [departmentFilter, setDepartmentFilter] = useState('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [updatingId, setUpdatingId] = useState(null);
  const [realtimeConnected, setRealtimeConnected] = useState(false);
  const [activeTooltipId, setActiveTooltipId] = useState(null);
  const [activeInfoModal, setActiveInfoModal] = useState(null); // 'response' | 'resolution' | 'sla'
  const [mapView, setMapView] = useState('hotspots'); // 'issues', 'hotspots', 'heatmap'
  const [chartView, setChartView] = useState('category'); // 'category', 'trend'
  const [fetchError, setFetchError] = useState(null);

  // Fetch ALL complaints directly from issueService (includes status_history audit relation)
  const fetchComplaintsDirectly = useCallback(async () => {
    setLoading(true);
    setFetchError(null);
    try {
      const { data: allComplaints, error } = await issueService.fetchAllComplaints();

      if (error) {
        console.warn('Database query notice:', error);
        setFetchError(error.message || 'Database query error');
      }

      // Deduplicate by unique complaint ID
      const uniqueMap = new Map();
      (allComplaints || []).forEach((item) => {
        if (item && item.id && !uniqueMap.has(item.id)) {
          uniqueMap.set(item.id, item);
        }
      });

      setComplaints(Array.from(uniqueMap.values()));
    } catch (err) {
      console.error('Direct complaint fetch exception:', err);
      setFetchError(err.message || 'Failed to connect to municipal database.');
      toast.error('Failed to fetch complaints from database.');
    } finally {
      setLoading(false);
    }
  }, [toast]);

  useEffect(() => {
    fetchComplaintsDirectly();

    // Subscribe to both complaints and status_history table realtime events
    const channel = supabase
      .channel('admin-realtime-complaints')
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'complaints' },
        async (payload) => {
          console.log('Realtime complaints event in AdminPage:', payload);
          if (payload.eventType === 'INSERT' && payload.new?.id) {
            try {
              const { data: newItem } = await issueService.fetchIssueById(payload.new.id);
              const itemToAdd = newItem || payload.new;
              setComplaints((prev) => {
                if (prev.some((c) => c.id === itemToAdd.id)) {
                  return prev.map((c) => (c.id === itemToAdd.id ? { ...c, ...itemToAdd } : c));
                }
                return [itemToAdd, ...prev];
              });
            } catch (fetchErr) {
              console.warn('Realtime INSERT item fetch warning:', fetchErr);
              setComplaints((prev) => {
                if (prev.some((c) => c.id === payload.new.id)) return prev;
                return [payload.new, ...prev];
              });
            }
          } else if (payload.eventType === 'UPDATE' && payload.new?.id) {
            try {
              const { data: updatedItem } = await issueService.fetchIssueById(payload.new.id);
              if (updatedItem) {
                setComplaints((prev) =>
                  prev.map((c) => (c.id === payload.new.id ? { ...c, ...updatedItem } : c))
                );
              } else {
                setComplaints((prev) =>
                  prev.map((c) => (c.id === payload.new.id ? { ...c, ...payload.new } : c))
                );
              }
            } catch {
              setComplaints((prev) =>
                prev.map((c) => (c.id === payload.new.id ? { ...c, ...payload.new } : c))
              );
            }
          } else if (payload.eventType === 'DELETE' && payload.old?.id) {
            setComplaints((prev) => prev.filter((c) => c.id !== payload.old.id));
          }
        }
      )
      .on(
        'postgres_changes',
        { event: '*', schema: 'public', table: 'status_history' },
        async (payload) => {
          console.log('Realtime status_history event in AdminPage:', payload);
          fetchComplaintsDirectly();
        }
      )
      .subscribe((status, err) => {
        if (status === 'SUBSCRIBED') {
          setRealtimeConnected(true);
        }
        if (err) {
          console.error('Admin Realtime subscription error:', err);
        }
      });

    return () => {
      supabase.removeChannel(channel);
    };
  }, [fetchComplaintsDirectly]);

  const handleStatusChange = async (complaintId, newStatus) => {
    setUpdatingId(complaintId);
    try {
      const currentComplaint = complaints.find((c) => c.id === complaintId);
      const oldStatus = currentComplaint ? currentComplaint.status || 'Pending' : 'Pending';

      const { error } = await issueService.updateComplaintStatus(complaintId, newStatus, oldStatus);

      if (error) {
        toast.error(`Update failed: ${error.message}`);
      } else {
        toast.success(`Status updated to "${newStatus}"`);
        await fetchComplaintsDirectly();
      }
    } catch (err) {
      console.error('Status update exception:', err);
      toast.error('Failed to update status');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleDepartmentChange = async (complaintId, newDept) => {
    setUpdatingId(complaintId);
    try {
      const { error } = await issueService.updateComplaintDepartment(complaintId, newDept);
      if (error) {
        toast.error(`Department routing failed: ${error.message}`);
      } else {
        toast.success(`Routed to "${newDept}"`);
        await fetchComplaintsDirectly();
      }
    } catch (err) {
      console.error('Department update exception:', err);
      toast.error('Failed to update department routing');
    } finally {
      setUpdatingId(null);
    }
  };

  const handleAdminDelete = async (complaintId) => {
    setComplaints((prev) => prev.filter((c) => c.id !== complaintId));
    toast.success('Complaint dismissed and removed from queue.');

    try {
      const { error } = await supabase.from('complaints').delete().eq('id', complaintId);
      issueService.deleteComplaint(complaintId);
      if (error) {
        console.error('Admin delete complaint error:', error);
      }
    } catch (err) {
      console.error('Admin delete complaint exception:', err);
    }
  };

  // --------------------------------------------------------------------------
  // FILTER INTEGRATION & REAL-TIME SLA ANALYTICS CALCULATIONS
  // --------------------------------------------------------------------------

  // 1. Filter complaints based on Search, Category, Department, Status, and Severity
  const filteredComplaints = useMemo(() => {
    return complaints.filter((c) => {
      const matchesStatus =
        statusFilter === 'all' || (c.status || '').toLowerCase() === statusFilter.toLowerCase();

      const matchesSeverity =
        severityFilter === 'all' ||
        (c.severity || c.severity_score || '').toLowerCase() === severityFilter.toLowerCase();

      const matchesCategory =
        categoryFilter === 'all' || (c.category || '').toLowerCase() === categoryFilter.toLowerCase();

      const complaintDept = c.recommended_department || getRecommendedDepartment(c.category);
      const matchesDepartment =
        departmentFilter === 'all' || complaintDept.toLowerCase() === departmentFilter.toLowerCase();

      const matchesSearch =
        (c.title || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.description || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.address || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.profiles?.email || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        (c.category || '').toLowerCase().includes(searchQuery.toLowerCase()) ||
        complaintDept.toLowerCase().includes(searchQuery.toLowerCase());

      return matchesStatus && matchesSeverity && matchesCategory && matchesDepartment && matchesSearch;
    });
  }, [complaints, statusFilter, severityFilter, categoryFilter, departmentFilter, searchQuery]);

  // 2. Dynamic SLA & Performance Analytics over filtered complaints
  const filteredAnalytics = useMemo(() => {
    return slaService.calculateSlaAnalytics(filteredComplaints);
  }, [filteredComplaints]);

  // 3. Department Performance Breakdown (Filtered)
  const departmentPerformance = useMemo(() => {
    return slaService.calculateDepartmentPerformance(filteredComplaints);
  }, [filteredComplaints]);

  // 4. Category Performance Breakdown (Filtered)
  const categoryPerformance = useMemo(() => {
    return slaService.calculateCategoryPerformance(filteredComplaints);
  }, [filteredComplaints]);

  // 5. Time Trend Data (Filtered)
  const timeTrendData = useMemo(() => {
    return slaService.calculateTimeTrendData(filteredComplaints);
  }, [filteredComplaints]);

  // Civic Hotspot Intelligence Hook - Automatic proximity clustering, risk scoring, smart department routing
  const {
    allHotspots,
    filteredHotspots,
    summaryMetrics: hotspotMetrics,
    radiusMeters: hotspotRadius,
    setRadiusMeters: setHotspotRadius,
    minComplaints: hotspotMinComplaints,
    setMinComplaints: setHotspotMinComplaints,
    filterRisk: hotspotRiskFilter,
    setFilterRisk: setHotspotRiskFilter,
    filterDepartment: hotspotDeptFilter,
    setFilterDepartment: setHotspotDeptFilter,
    filterStatus: hotspotStatusFilter,
    setFilterStatus: setHotspotStatusFilter,
    filterSearch: hotspotSearch,
    setFilterSearch: setHotspotSearch,
    selectedHotspot,
    setSelectedHotspot,
    updateStatus: updateHotspotStatus,
    updateDepartment: updateHotspotDepartment,
  } = useHotspots(complaints);

  // Category Chart Data for BarChart
  const categoryChartData = useMemo(() => {
    const counts = {};
    filteredComplaints.forEach((c) => {
      const cat = c.category || 'General';
      counts[cat] = (counts[cat] || 0) + 1;
    });
    return Object.entries(counts).map(([name, value]) => ({ name, value }));
  }, [filteredComplaints]);

  // Priority Queue Table sorting (Urban Impact Score: 100 -> 0)
  const prioritySortedComplaints = useMemo(() => {
    return [...filteredComplaints].sort((a, b) => {
      const impactA = calculateUrbanImpactScore(a, complaints).score;
      const impactB = calculateUrbanImpactScore(b, complaints).score;
      if (impactA !== impactB) return impactB - impactA;
      return new Date(b.created_at || 0) - new Date(a.created_at || 0);
    });
  }, [filteredComplaints, complaints]);

  // City Map Center (defaults to first hotspot, first complaint, or Delhi fallback)
  const mapCenter = useMemo(() => {
    if (filteredHotspots.length > 0 && filteredHotspots[0].centerLat && filteredHotspots[0].centerLng) {
      return [filteredHotspots[0].centerLat, filteredHotspots[0].centerLng];
    }
    const valid = filteredComplaints.find((c) => c.latitude && c.longitude);
    if (valid) return [valid.latitude, valid.longitude];
    return [28.6139, 77.2090];
  }, [filteredHotspots, filteredComplaints]);

  const mapMarkers = useMemo(() => {
    return filteredComplaints.filter((c) => c.latitude && c.longitude);
  }, [filteredComplaints]);

  const getSeverityBadgeColor = (sev) => {
    switch ((sev || '').toLowerCase()) {
      case 'critical':
        return 'bg-red-500/10 text-red-700 border border-red-200 dark:bg-red-500/10 dark:text-red-400 dark:border dark:border-red-500/30';
      case 'high':
        return 'bg-amber-500/10 text-amber-700 border border-amber-200 dark:bg-amber-500/10 dark:text-amber-400 dark:border dark:border-amber-500/30';
      case 'medium':
        return 'bg-blue-500/10 text-blue-700 border border-blue-200 dark:bg-blue-500/10 dark:text-blue-400 dark:border dark:border-blue-500/30';
      case 'low':
      default:
        return 'bg-emerald-500/10 text-emerald-700 border border-emerald-200 dark:bg-emerald-500/10 dark:text-emerald-400 dark:border dark:border-emerald-500/30';
    }
  };

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8 space-y-8 text-slate-900 dark:text-slate-100 transition-colors duration-300">
      {/* Tactical Header */}
      <PageHeader
        title="Authority Dashboard & Command Center"
        description="Real-time municipal GIS monitoring, dynamic SLA performance analytics, and automated department dispatch."
        badge={
          <div className="flex items-center gap-2">
            <Badge variant="indigo">Municipal Command Authority</Badge>
            {realtimeConnected && (
              <span className="inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full bg-emerald-100 dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 text-[10px] font-bold tracking-wider border border-emerald-300 dark:border-emerald-500/30">
                <Radio className="w-3 h-3 text-emerald-600 dark:text-emerald-400 animate-pulse" /> Live Telemetry
              </span>
            )}
          </div>
        }
        action={
          <Button
            onClick={fetchComplaintsDirectly}
            disabled={loading}
            variant="outline"
            className="text-slate-700 dark:text-slate-300 bg-white/80 dark:bg-slate-800/50 border-slate-200/80 dark:border-slate-700/80 hover:bg-slate-50 dark:hover:bg-slate-800 cursor-pointer shadow-xs"
          >
            <RefreshCw className={`w-4 h-4 mr-2 ${loading ? 'animate-spin' : ''}`} />
            Sync Data
          </Button>
        }
      />

      {/* DYNAMIC REAL-TIME SLA KPI CARDS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* KPI 1: Total Complaints */}
        <div className="p-5 rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:dark:border-blue-500/40 hover:dark:shadow-[0_0_20px_rgba(59,130,246,0.15)] transition-all duration-300 space-y-2">
          <div className="flex items-center justify-between">
            <span className="text-[11px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">Total Reports</span>
            <div className="w-9 h-9 rounded-xl bg-blue-100 dark:bg-blue-600/20 text-blue-600 dark:text-blue-400 flex items-center justify-center border border-blue-200 dark:border-blue-500/30">
              <Layers className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold text-blue-600 dark:text-blue-400">
            {loading ? '...' : filteredAnalytics.totalComplaints}
          </div>
          <p className="text-[11px] text-slate-500 dark:text-slate-400">
            {filteredAnalytics.resolvedCount} resolved &bull; {filteredAnalytics.inProgressCount} in progress
          </p>
        </div>

        {/* KPI 2: Average Response Time */}
        <div className="p-5 rounded-2xl bg-white/80 border border-amber-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-amber-500/30 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:dark:border-amber-500/60 hover:dark:shadow-[0_0_20px_rgba(245,158,11,0.15)] transition-all duration-300 space-y-2 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-amber-700 dark:text-amber-400">Avg Response Time</span>
              <button
                type="button"
                onClick={() => setActiveInfoModal(activeInfoModal === 'response' ? null : 'response')}
                className="text-amber-500 hover:text-amber-700 dark:hover:text-amber-300 cursor-pointer p-0.5"
                title="View Response Time Definition"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="w-9 h-9 rounded-xl bg-amber-100 dark:bg-amber-500/10 text-amber-600 dark:text-amber-400 flex items-center justify-center border border-amber-200 dark:border-amber-500/30">
              <Clock className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold text-amber-600 dark:text-amber-400">
            {loading ? '...' : filteredAnalytics.avgResponseTimeFormatted}
          </div>
          <p className="text-[11px] text-amber-700/80 dark:text-amber-300">
            Creation to first "In Progress" status
          </p>

          {/* Response Time Tooltip Modal */}
          {activeInfoModal === 'response' && (
            <div className="absolute left-2 top-14 z-50 w-72 p-3 rounded-2xl bg-slate-900 text-white shadow-xl border border-slate-700 text-xs space-y-2 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 font-bold">
                <span className="text-amber-400 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" /> Response Time Metric
                </span>
                <button
                  onClick={() => setActiveInfoModal(null)}
                  className="text-slate-400 hover:text-white"
                >
                  &times;
                </button>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Calculated strictly as time elapsed from <strong>Complaint Creation</strong> to the <strong>First transition to "In Progress"</strong>.
              </p>
              <div className="p-2 rounded-lg bg-slate-800 text-[10px] text-slate-400 font-mono">
                Complaint Created &rarr; First In Progress &rarr; Response Time
              </div>
            </div>
          )}
        </div>

        {/* KPI 3: Average Resolution Time (REPLACES HARDCODED 3.8 Hours) */}
        <div className="p-5 rounded-2xl bg-white/80 border border-indigo-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:dark:border-blue-500/40 hover:dark:shadow-[0_0_20px_rgba(59,130,246,0.15)] transition-all duration-300 space-y-2 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-indigo-700 dark:text-indigo-300">Avg Resolution Time</span>
              <button
                type="button"
                onClick={() => setActiveInfoModal(activeInfoModal === 'resolution' ? null : 'resolution')}
                className="text-indigo-500 hover:text-indigo-700 dark:hover:text-indigo-300 cursor-pointer p-0.5"
                title="View Resolution Time Definition"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="w-9 h-9 rounded-xl bg-indigo-100 dark:bg-indigo-600/20 text-indigo-600 dark:text-indigo-400 flex items-center justify-center border border-indigo-200 dark:border-indigo-500/30">
              <Activity className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold text-indigo-600 dark:text-indigo-300">
            {loading ? '...' : filteredAnalytics.avgResolutionTimeFormatted}
          </div>
          <p className="text-[11px] text-indigo-600/80 dark:text-indigo-300">
            Creation to first "Resolved" status
          </p>

          {/* Resolution Time Tooltip Modal */}
          {activeInfoModal === 'resolution' && (
            <div className="absolute left-2 top-14 z-50 w-72 p-3 rounded-2xl bg-slate-900 text-white shadow-xl border border-slate-700 text-xs space-y-2 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 font-bold">
                <span className="text-indigo-400 flex items-center gap-1">
                  <Info className="w-3.5 h-3.5" /> Resolution Time Metric
                </span>
                <button
                  onClick={() => setActiveInfoModal(null)}
                  className="text-slate-400 hover:text-white"
                >
                  &times;
                </button>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Calculated as time elapsed from <strong>Complaint Creation</strong> to the <strong>First transition to "Resolved"</strong>.
              </p>
              <div className="p-2 rounded-lg bg-slate-800 text-[10px] text-slate-400 font-mono">
                Complaint Created &rarr; First Resolved &rarr; Resolution Time
              </div>
            </div>
          )}
        </div>

        {/* KPI 4: SLA Compliance % & SLA Breaches */}
        <div className="p-5 rounded-2xl bg-white/80 border border-emerald-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-emerald-500/30 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] hover:dark:border-emerald-500/60 hover:dark:shadow-[0_0_20px_rgba(16,185,129,0.15)] transition-all duration-300 space-y-2 relative">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-1.5">
              <span className="text-[11px] font-bold uppercase tracking-wider text-emerald-700 dark:text-emerald-400">SLA Compliance %</span>
              <button
                type="button"
                onClick={() => setActiveInfoModal(activeInfoModal === 'sla' ? null : 'sla')}
                className="text-emerald-500 hover:text-emerald-700 dark:hover:text-emerald-300 cursor-pointer p-0.5"
                title="View SLA Compliance Definition"
              >
                <HelpCircle className="w-3.5 h-3.5" />
              </button>
            </div>
            <div className="w-9 h-9 rounded-xl bg-emerald-100 dark:bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 flex items-center justify-center border border-emerald-200 dark:border-emerald-500/30">
              <CheckCircle2 className="w-4 h-4" />
            </div>
          </div>
          <div className="text-3xl font-bold text-emerald-600 dark:text-emerald-400">
            {loading ? '...' : filteredAnalytics.slaComplianceFormatted}
          </div>
          <p className="text-[11px] text-emerald-700/90 dark:text-emerald-300 flex items-center justify-between">
            <span>Met within threshold</span>
            <span className="font-bold text-rose-600 dark:text-rose-400">
              {filteredAnalytics.slaBreachesCount} Breached
            </span>
          </p>

          {/* SLA Compliance Tooltip Modal */}
          {activeInfoModal === 'sla' && (
            <div className="absolute right-2 top-14 z-50 w-72 p-3 rounded-2xl bg-slate-900 text-white shadow-xl border border-slate-700 text-xs space-y-2 animate-in fade-in zoom-in-95">
              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 font-bold">
                <span className="text-emerald-400 flex items-center gap-1">
                  <ShieldAlert className="w-3.5 h-3.5" /> SLA Compliance Metric
                </span>
                <button
                  onClick={() => setActiveInfoModal(null)}
                  className="text-slate-400 hover:text-white"
                >
                  &times;
                </button>
              </div>
              <p className="text-[11px] text-slate-300 leading-relaxed">
                Percentage of tickets resolved or active within their priority SLA threshold:
              </p>
              <div className="p-2 rounded-lg bg-slate-800 text-[10px] text-slate-300 space-y-0.5 font-mono">
                <div>Critical &rarr; 4h limit</div>
                <div>High &rarr; 12h limit</div>
                <div>Medium &rarr; 24h limit</div>
                <div>Low &rarr; 48h limit</div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* DEPARTMENT PERFORMANCE METRICS GRID */}
      <div className="p-5 rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 space-y-4 transition-all">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-3">
          <div className="flex items-center gap-2">
            <Building2 className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Department Performance Analytics & Workload
            </h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Database Calculated Metrics</span>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-5 gap-3">
          {departmentPerformance.map((dept) => {
            const isSelected = departmentFilter.toLowerCase() === dept.department.toLowerCase();
            const isReview = dept.department === 'Review Required';

            return (
              <div
                key={dept.department}
                onClick={() =>
                  setDepartmentFilter(isSelected ? 'all' : dept.department)
                }
                className={`p-3.5 rounded-xl border transition-all cursor-pointer space-y-2 ${
                  isSelected
                    ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 dark:border-blue-500 shadow-xs ring-1 ring-blue-400'
                    : isReview
                    ? 'bg-amber-50/50 dark:bg-amber-950/20 border-amber-200 dark:border-amber-900/40 hover:border-amber-400'
                    : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
                }`}
              >
                <div className="flex items-center justify-between">
                  <span className="text-[10px] font-bold text-slate-500 dark:text-slate-400 truncate max-w-[130px]" title={dept.department}>
                    {dept.department}
                  </span>
                  <span className="px-1.5 py-0.5 rounded text-[9px] font-black bg-slate-200 dark:bg-slate-700 text-slate-800 dark:text-slate-200">
                    {dept.totalComplaints} total
                  </span>
                </div>

                <div className="text-sm font-black text-slate-900 dark:text-white">
                  {dept.activeCount > 0 ? `${dept.activeCount} Active Issues` : '0 Active Issues'}
                </div>

                <div className="pt-2 border-t border-slate-200/60 dark:border-slate-700/60 grid grid-cols-2 gap-1 text-[10px] font-mono">
                  <div>
                    <span className="text-slate-400 block text-[9px]">Avg Response</span>
                    <span className="font-bold text-amber-600 dark:text-amber-400">{dept.avgResponseTimeFormatted}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px]">Avg Resolution</span>
                    <span className="font-bold text-indigo-600 dark:text-indigo-400">{dept.avgResolutionTimeFormatted}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px]">SLA Compliance</span>
                    <span className="font-bold text-emerald-600 dark:text-emerald-400">{dept.slaComplianceFormatted}</span>
                  </div>
                  <div>
                    <span className="text-slate-400 block text-[9px]">SLA Breaches</span>
                    <span className={`font-bold ${dept.slaBreachesCount > 0 ? 'text-rose-600 dark:text-rose-400' : 'text-slate-400'}`}>
                      {dept.slaBreachesCount}
                    </span>
                  </div>
                </div>
              </div>
            );
          })}
        </div>
      </div>

      {/* ------------------------------------------------------------- */}
      {/* CIVIC HOTSPOT INTELLIGENCE SECTION                             */}
      {/* ------------------------------------------------------------- */}
      <div className="space-y-4 pt-4 border-t border-slate-200 dark:border-slate-800">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div>
            <div className="flex items-center gap-2">
              <div className="w-8 h-8 rounded-xl bg-rose-600/10 dark:bg-rose-500/20 text-rose-600 dark:text-rose-400 flex items-center justify-center border border-rose-200 dark:border-rose-500/30">
                <Flame className="w-4 h-4 text-rose-600 dark:text-rose-400" />
              </div>
              <h2 className="text-lg font-black text-slate-900 dark:text-white uppercase tracking-tight">
                Civic Hotspot Intelligence
              </h2>
              <span className="px-2.5 py-0.5 rounded-full text-[10px] font-bold bg-rose-100 text-rose-800 dark:bg-rose-950/80 dark:text-rose-300 border border-rose-300 dark:border-rose-800">
                Geographic Proximity Engine
              </span>
            </div>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-1">
              Automated spatial clustering, 5-factor risk scoring (0–100), and smart municipal department routing.
            </p>
          </div>

          <div className="flex items-center gap-2 text-xs font-mono">
            <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              Radius: <strong className="text-blue-600 dark:text-blue-400">{hotspotRadius}m</strong>
            </span>
            <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 border border-slate-200 dark:border-slate-700">
              Min Cluster: <strong className="text-indigo-600 dark:text-indigo-400">{hotspotMinComplaints} reports</strong>
            </span>
          </div>
        </div>

        {/* 4 Summary Cards as per Requirement 10 */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
          {/* Card 1: Critical Hotspots */}
          <div
            onClick={() => setHotspotRiskFilter(hotspotRiskFilter === 'Critical' ? 'all' : 'Critical')}
            className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border transition-all cursor-pointer space-y-1.5 shadow-sm hover:scale-[1.01] ${
              hotspotRiskFilter === 'Critical'
                ? 'border-rose-500 ring-2 ring-rose-500/20 bg-rose-50/50 dark:bg-rose-950/30'
                : 'border-slate-200/80 dark:border-slate-800 hover:border-rose-300 dark:hover:border-rose-800'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-rose-600 dark:text-rose-400">
              <span>Critical Hotspots</span>
              <AlertTriangle className="w-4 h-4 text-rose-600 dark:text-rose-400 animate-pulse" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-rose-600 dark:text-rose-400">
              {hotspotMetrics.critical} Critical
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Risk Score 75–100 &bull; Immediate Action
            </p>
          </div>

          {/* Card 2: High-Risk Hotspots */}
          <div
            onClick={() => setHotspotRiskFilter(hotspotRiskFilter === 'High' ? 'all' : 'High')}
            className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border transition-all cursor-pointer space-y-1.5 shadow-sm hover:scale-[1.01] ${
              hotspotRiskFilter === 'High'
                ? 'border-amber-500 ring-2 ring-amber-500/20 bg-amber-50/50 dark:bg-amber-950/30'
                : 'border-slate-200/80 dark:border-slate-800 hover:border-amber-300 dark:hover:border-amber-800'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-amber-600 dark:text-amber-400">
              <span>High-Risk Hotspots</span>
              <Flame className="w-4 h-4 text-amber-600 dark:text-amber-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-amber-600 dark:text-amber-400">
              {hotspotMetrics.high} High
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Risk Score 50–74 &bull; Priority Routing
            </p>
          </div>

          {/* Card 3: Moderate Hotspots */}
          <div
            onClick={() => setHotspotRiskFilter(hotspotRiskFilter === 'Moderate' ? 'all' : 'Moderate')}
            className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border transition-all cursor-pointer space-y-1.5 shadow-sm hover:scale-[1.01] ${
              hotspotRiskFilter === 'Moderate'
                ? 'border-yellow-500 ring-2 ring-yellow-500/20 bg-yellow-50/50 dark:bg-yellow-950/30'
                : 'border-slate-200/80 dark:border-slate-800 hover:border-yellow-300 dark:hover:border-yellow-800'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-yellow-600 dark:text-yellow-400">
              <span>Moderate Hotspots</span>
              <Zap className="w-4 h-4 text-yellow-600 dark:text-yellow-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-yellow-600 dark:text-yellow-400">
              {hotspotMetrics.moderate} Moderate
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              Risk Score 25–49 &bull; Scheduled Review
            </p>
          </div>

          {/* Card 4: Total Active Hotspots */}
          <div
            onClick={() => setHotspotRiskFilter('all')}
            className={`p-4 rounded-2xl bg-white dark:bg-slate-900 border transition-all cursor-pointer space-y-1.5 shadow-sm hover:scale-[1.01] ${
              hotspotRiskFilter === 'all'
                ? 'border-blue-500 ring-2 ring-blue-500/20 bg-blue-50/50 dark:bg-blue-950/30'
                : 'border-slate-200/80 dark:border-slate-800 hover:border-blue-300 dark:hover:border-blue-800'
            }`}
          >
            <div className="flex items-center justify-between text-[11px] font-bold uppercase tracking-wider text-blue-600 dark:text-blue-400">
              <span>Total Active Hotspots</span>
              <Layers className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            </div>
            <div className="text-2xl sm:text-3xl font-black text-blue-600 dark:text-blue-400">
              {hotspotMetrics.totalActive} Total
            </div>
            <p className="text-[11px] text-slate-500 dark:text-slate-400">
              {hotspotMetrics.totalReports} total reports in clusters
            </p>
          </div>
        </div>
      </div>

      {/* Live GIS Map Container & Analytics Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Live GIS Map Container */}
        <div className="lg:col-span-2 rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] p-5 space-y-4 transition-all duration-300">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b border-slate-100 dark:border-slate-800/80 pb-3">
            <div className="flex items-center gap-2">
              <MapPin className="w-5 h-5 text-blue-600 dark:text-blue-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                Urban Hotspot Intelligence Map
              </h3>
            </div>

            {/* Map View Switcher Controls */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setMapView('issues')}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  mapView === 'issues'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <MapPin className="w-3 h-3" /> Issues
              </button>
              <button
                type="button"
                onClick={() => setMapView('hotspots')}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  mapView === 'hotspots'
                    ? 'bg-rose-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Flame className="w-3 h-3" /> Hotspots ({filteredHotspots.length})
              </button>
              <button
                type="button"
                onClick={() => setMapView('heatmap')}
                className={`px-2.5 py-1 text-[11px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  mapView === 'heatmap'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <Zap className="w-3 h-3" /> Heatmap
              </button>
            </div>
          </div>

          <div className="h-[380px] w-full rounded-2xl overflow-hidden border border-slate-200 dark:border-slate-800 relative bg-slate-100 dark:bg-slate-950 transition-colors">
            {/* Empty Hotspots Banner */}
            {mapView !== 'issues' && filteredHotspots.length === 0 && (
              <div className="absolute top-3 left-1/2 -translate-x-1/2 z-20 px-4 py-2 bg-slate-900/90 text-white text-xs font-semibold rounded-xl border border-slate-700 backdrop-blur-md shadow-lg flex items-center gap-2">
                <AlertCircle className="w-4 h-4 text-amber-400" />
                <span>No active hotspots detected matching parameters (Radius: {hotspotRadius}m, Min: {hotspotMinComplaints} reports)</span>
              </div>
            )}

            <MapContainer
              center={mapCenter}
              zoom={12}
              scrollWheelZoom={false}
              className="h-full w-full z-10"
            >
              <TileLayer
                attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
                url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
              />

              {/* View Mode 1: Hotspots (Concentration Circles with Risk Level Colors) */}
              {mapView === 'hotspots' &&
                filteredHotspots.map((h) => {
                  const color = h.scoringConfig?.strokeColor || '#ef4444';
                  const fillColor = h.scoringConfig?.fillColor || '#ef4444';
                  return (
                    <CircleMarker
                      key={h.id}
                      center={[h.centerLat, h.centerLng]}
                      radius={Math.max(16, Math.min(42, 14 + h.totalComplaints * 3))}
                      pathOptions={{
                        color: color,
                        fillColor: fillColor,
                        fillOpacity: 0.55,
                        weight: h.priority === 'CRITICAL' ? 3 : 2,
                      }}
                      eventHandlers={{
                        click: () => setSelectedHotspot(h),
                      }}
                    >
                      <Popup className="tactical-popup">
                        <div className="p-2 space-y-2 max-w-xs text-slate-900">
                          <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-1.5">
                            <span
                              className="px-2 py-0.5 rounded text-[10px] font-black uppercase text-white shadow-xs"
                              style={{ backgroundColor: color }}
                            >
                              {h.riskLevel} &bull; {h.priority}
                            </span>
                            <span className="font-mono text-[11px] font-bold text-slate-700">
                              Risk: {h.riskScore} / 100
                            </span>
                          </div>

                          <div className="space-y-0.5">
                            <div className="font-extrabold text-sm text-slate-900">{h.id}</div>
                            <div className="text-xs text-slate-600 font-medium">{h.areaName}</div>
                          </div>

                          <div className="grid grid-cols-2 gap-1.5 text-[11px] bg-slate-50 p-2 rounded-lg border border-slate-200">
                            <div>
                              <span className="text-slate-500 block text-[9px] uppercase font-bold">Total Reports</span>
                              <span className="font-extrabold text-slate-900 text-sm">{h.totalComplaints} Reports</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block text-[9px] uppercase font-bold">Dominant Issue</span>
                              <span className="font-bold text-blue-700 capitalize">{h.dominantCategory}</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block text-[9px] uppercase font-bold">Unresolved</span>
                              <span className="font-bold text-rose-600">{h.unresolvedCount} Active</span>
                            </div>
                            <div>
                              <span className="text-slate-500 block text-[9px] uppercase font-bold">Assigned Dept</span>
                              <span className="font-bold text-slate-800 text-[10px] truncate block">{h.assignedDepartment}</span>
                            </div>
                          </div>

                          <p className="text-[10px] text-slate-500 italic">
                            Center: {Number(h.centerLat).toFixed(4)}, {Number(h.centerLng).toFixed(4)} ({h.radiusMeters}m radius)
                          </p>

                          <button
                            type="button"
                            onClick={() => setSelectedHotspot(h)}
                            className="w-full py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer shadow-xs"
                          >
                            <Flame className="w-3.5 h-3.5" /> View Hotspot Details &amp; Issues
                          </button>
                        </div>
                      </Popup>
                    </CircleMarker>
                  );
                })}

              {/* View Mode 2: Heatmap (Glowing Gradient Concentric Circles) */}
              {mapView === 'heatmap' &&
                filteredHotspots.map((h) => {
                  const color = h.scoringConfig?.strokeColor || '#ef4444';
                  const fillColor = h.scoringConfig?.fillColor || '#ef4444';
                  return (
                    <React.Fragment key={`heat-group-${h.id}`}>
                      {/* Outer aura */}
                      <CircleMarker
                        center={[h.centerLat, h.centerLng]}
                        radius={Math.max(28, Math.min(65, 20 + h.totalComplaints * 4))}
                        pathOptions={{
                          color: color,
                          fillColor: fillColor,
                          fillOpacity: 0.25,
                          weight: 1,
                        }}
                        eventHandlers={{
                          click: () => setSelectedHotspot(h),
                        }}
                      />
                      {/* Core intense center */}
                      <CircleMarker
                        center={[h.centerLat, h.centerLng]}
                        radius={Math.max(12, Math.min(26, 8 + h.totalComplaints * 2))}
                        pathOptions={{
                          color: '#ffffff',
                          fillColor: fillColor,
                          fillOpacity: 0.85,
                          weight: 2,
                        }}
                        eventHandlers={{
                          click: () => setSelectedHotspot(h),
                        }}
                      >
                        <Popup className="tactical-popup">
                          <div className="p-2 text-xs text-slate-900 space-y-1.5 max-w-xs">
                            <div className="flex items-center justify-between gap-2 border-b border-slate-200 pb-1">
                              <span
                                className="px-2 py-0.5 rounded text-[10px] font-black uppercase text-white"
                                style={{ backgroundColor: color }}
                              >
                                {h.riskLevel} Heat Zone
                              </span>
                              <span className="font-mono text-xs font-bold text-slate-700">
                                Risk: {h.riskScore} / 100
                              </span>
                            </div>
                            <p className="text-[11px] font-bold text-slate-800">{h.areaName}</p>
                            <p className="text-[11px] text-slate-600">{h.totalComplaints} reports concentrated</p>
                            <p className="text-[11px] font-bold text-indigo-700 capitalize">
                              Dominant: {h.dominantCategory} &bull; {h.assignedDepartment}
                            </p>
                            <button
                              type="button"
                              onClick={() => setSelectedHotspot(h)}
                              className="w-full mt-2 py-1.5 bg-blue-600 hover:bg-blue-700 text-white font-bold rounded-lg text-xs transition-colors flex items-center justify-center gap-1 cursor-pointer"
                            >
                              <Flame className="w-3.5 h-3.5" /> View Hotspot Details
                            </button>
                          </div>
                        </Popup>
                      </CircleMarker>
                    </React.Fragment>
                  );
                })}

              {/* View Mode 3: Individual Pins */}
              {mapView === 'issues' &&
                mapMarkers.map((c) => {
                  const markerIcon = createMarkerIcon(c.severity || c.severity_score, c.status);
                  return (
                    <Marker
                      key={c.id}
                      position={[c.latitude, c.longitude]}
                      icon={markerIcon}
                    >
                      <Popup className="tactical-popup">
                        <div className="p-1 space-y-1.5 max-w-xs text-slate-900">
                          <div className="flex items-center justify-between gap-2">
                            <span className="font-bold text-xs capitalize">{c.category}</span>
                            <span className="px-1.5 py-0.5 rounded bg-slate-900 text-white font-mono text-[9px]">
                              {c.status || 'Pending'}
                            </span>
                          </div>
                          <h4 className="font-bold text-sm leading-tight text-slate-900">{c.title}</h4>
                          <p className="text-xs text-slate-600">{c.address}</p>
                          {c.ai_summary && (
                            <p className="text-[11px] italic text-slate-700 bg-slate-100 p-1.5 rounded">
                              AI: {c.ai_summary}
                            </p>
                          )}
                          <div className="pt-1.5 flex items-center justify-between border-t border-slate-200 text-[11px]">
                            <span className="font-bold text-blue-600 flex items-center gap-1">
                              👍 I Face This Too: {c.upvotes || 1}
                            </span>
                            <span className="text-[10px] text-slate-500 font-mono">
                              Priority: {c.priority || 'Medium'}
                            </span>
                          </div>
                        </div>
                      </Popup>
                    </Marker>
                  );
                })}
            </MapContainer>
          </div>
        </div>

        {/* Analytics & Department Breakdown / Time Trend Chart */}
        <div className="rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] p-5 space-y-4 flex flex-col justify-between transition-all duration-300">
          <div className="border-b border-slate-100 dark:border-slate-800/80 pb-3 flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Sparkles className="w-4 h-4 text-indigo-600 dark:text-indigo-400" />
              <h3 className="text-sm font-bold text-slate-900 dark:text-white uppercase tracking-wider">
                {chartView === 'category' ? 'Category Breakdown' : 'Historical Time Trend'}
              </h3>
            </div>

            {/* Chart Switcher Buttons */}
            <div className="flex items-center gap-1 bg-slate-100 dark:bg-slate-800 p-1 rounded-xl border border-slate-200 dark:border-slate-700">
              <button
                type="button"
                onClick={() => setChartView('category')}
                className={`px-2 py-0.5 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  chartView === 'category'
                    ? 'bg-blue-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <BarChart3 className="w-3 h-3" /> Category
              </button>
              <button
                type="button"
                onClick={() => setChartView('trend')}
                className={`px-2 py-0.5 text-[10px] font-bold rounded-lg transition-all flex items-center gap-1 cursor-pointer ${
                  chartView === 'trend'
                    ? 'bg-indigo-600 text-white shadow-sm'
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-900 dark:hover:text-white'
                }`}
              >
                <TrendingUp className="w-3 h-3" /> Trend
              </button>
            </div>
          </div>

          <div className="h-[280px] w-full flex items-center justify-center">
            {chartView === 'category' ? (
              categoryChartData.length > 0 ? (
                <ResponsiveContainer width="100%" height="100%">
                  <BarChart data={categoryChartData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#1e293b' : '#e2e8f0'} />
                    <XAxis dataKey="name" stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} tick={{ fontSize: 10 }} />
                    <YAxis stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} tick={{ fontSize: 10 }} />
                    <Tooltip
                      contentStyle={{
                        backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                        borderColor: theme === 'dark' ? '#334155' : '#cbd5e1',
                        borderRadius: '12px',
                        color: theme === 'dark' ? '#ffffff' : '#0f172a',
                      }}
                    />
                    <Bar dataKey="value" name="Complaints" fill="#3b82f6" radius={[6, 6, 0, 0]}>
                      {categoryChartData.map((entry, index) => (
                        <Cell key={`cell-${index}`} fill={CHART_COLORS[index % CHART_COLORS.length]} />
                      ))}
                    </Bar>
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <p className="text-xs text-slate-400">No response data available</p>
              )
            ) : timeTrendData.length > 0 ? (
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={timeTrendData} margin={{ top: 10, right: 10, left: -20, bottom: 0 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke={theme === 'dark' ? '#1e293b' : '#e2e8f0'} />
                  <XAxis dataKey="date" stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} tick={{ fontSize: 10 }} />
                  <YAxis stroke={theme === 'dark' ? '#94a3b8' : '#64748b'} tick={{ fontSize: 10 }} />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: theme === 'dark' ? '#0f172a' : '#ffffff',
                      borderColor: theme === 'dark' ? '#334155' : '#cbd5e1',
                      borderRadius: '12px',
                      color: theme === 'dark' ? '#ffffff' : '#0f172a',
                    }}
                  />
                  <Legend wrapperStyle={{ fontSize: 10 }} />
                  <Bar dataKey="Complaints" name="Complaints" fill="#3b82f6" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="Resolved" name="Resolved" fill="#10b981" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <p className="text-xs text-slate-400">No trend data available</p>
            )}
          </div>

          <div className="pt-2 border-t border-slate-100 dark:border-slate-800/80 flex items-center justify-between text-xs text-slate-600 dark:text-slate-400 font-medium">
            <span>Pending Tickets: <strong className="text-amber-600 dark:text-amber-400">{filteredAnalytics.pendingCount}</strong></span>
            <span>Resolved Tickets: <strong className="text-emerald-600 dark:text-emerald-400">{filteredAnalytics.resolvedCount}</strong></span>
          </div>
        </div>
      </div>

      {/* CIVIC HOTSPOT INTELLIGENCE PRIORITY ACTION QUEUE */}
      <HotspotPriorityQueue
        hotspots={filteredHotspots}
        allHotspotsCount={allHotspots.length}
        filterRisk={hotspotRiskFilter}
        setFilterRisk={setHotspotRiskFilter}
        filterDepartment={hotspotDeptFilter}
        setFilterDepartment={setHotspotDeptFilter}
        filterStatus={hotspotStatusFilter}
        setFilterStatus={setHotspotStatusFilter}
        filterSearch={hotspotSearch}
        setFilterSearch={setHotspotSearch}
        radiusMeters={hotspotRadius}
        setRadiusMeters={setHotspotRadius}
        minComplaints={hotspotMinComplaints}
        setMinComplaints={setHotspotMinComplaints}
        onSelectHotspot={(h) => setSelectedHotspot(h)}
      />

      {/* CATEGORY PERFORMANCE ANALYTICS BREAKDOWN TABLE */}
      <div className="p-5 rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 space-y-3 transition-all">
        <div className="flex items-center justify-between border-b border-slate-100 dark:border-slate-800/80 pb-2">
          <div className="flex items-center gap-2">
            <Tag className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <h3 className="text-xs font-bold text-slate-900 dark:text-white uppercase tracking-wider">
              Category SLA Performance Breakdown
            </h3>
          </div>
          <span className="text-[10px] font-mono text-slate-400">Database Calculated Metrics</span>
        </div>

        <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-6 gap-3">
          {categoryPerformance.map((cat) => (
            <div
              key={cat.categoryId}
              onClick={() =>
                setCategoryFilter(categoryFilter === cat.categoryId ? 'all' : cat.categoryId)
              }
              className={`p-3 rounded-xl border transition-all cursor-pointer space-y-1 ${
                categoryFilter === cat.categoryId
                  ? 'bg-blue-50 dark:bg-blue-950/60 border-blue-400 dark:border-blue-500 shadow-xs'
                  : 'bg-slate-50/70 dark:bg-slate-800/40 border-slate-200 dark:border-slate-700/80 hover:border-slate-300 dark:hover:border-slate-600'
              }`}
            >
              <div className="text-[10px] font-bold text-slate-500 dark:text-slate-400 truncate">
                {cat.label}
              </div>
              <div className="text-xs font-black text-slate-900 dark:text-white">
                {cat.totalCount} reports ({cat.resolvedCount} res)
              </div>
              <div className="text-[9px] font-mono text-slate-500 dark:text-slate-400 pt-1 border-t border-slate-200/50 dark:border-slate-700/50 flex flex-col gap-0.5">
                <span>Avg Res: <strong className="text-indigo-600 dark:text-indigo-400">{cat.avgResolutionTimeFormatted}</strong></span>
                <span>SLA: <strong className="text-emerald-600 dark:text-emerald-400">{cat.slaComplianceFormatted}</strong></span>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Dynamic Filter Panel */}
      <div className="p-5 rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] space-y-4 transition-all duration-300">
        <div className="flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-2 text-xs font-bold text-slate-800 dark:text-slate-300 uppercase tracking-wider">
            <Filter className="w-4 h-4 text-blue-600 dark:text-blue-400" />
            <span>Interactive Priority & Department Filters</span>
          </div>

          {/* Search Bar */}
          <div className="relative w-full sm:w-72">
            <Input
              placeholder="Search by title, location, email..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-9 text-xs"
            />
            <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-2.5 pointer-events-none" />
          </div>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-3 pt-1">
          {/* Status Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Status Filter</label>
            <select
              value={statusFilter}
              onChange={(e) => setStatusFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:dark:border-blue-500 focus:dark:ring-1 focus:dark:ring-blue-500 transition-colors cursor-pointer"
            >
              <option value="all">All Statuses ({complaints.length})</option>
              <option value="pending">Pending ({filteredAnalytics.pendingCount})</option>
              <option value="in progress">In Progress ({filteredAnalytics.inProgressCount})</option>
              <option value="resolved">Resolved ({filteredAnalytics.resolvedCount})</option>
            </select>
          </div>

          {/* Severity Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Severity Level</label>
            <select
              value={severityFilter}
              onChange={(e) => setSeverityFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:dark:border-blue-500 focus:dark:ring-1 focus:dark:ring-blue-500 transition-colors cursor-pointer"
            >
              <option value="all">All Severities</option>
              <option value="critical">Critical (SLA 4h)</option>
              <option value="high">High (SLA 12h)</option>
              <option value="medium">Medium (SLA 24h)</option>
              <option value="low">Low (SLA 48h)</option>
            </select>
          </div>

          {/* Issue Category Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Issue Category</label>
            <select
              value={categoryFilter}
              onChange={(e) => setCategoryFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:dark:border-blue-500 focus:dark:ring-1 focus:dark:ring-blue-500 transition-colors cursor-pointer"
            >
              <option value="all">All Categories</option>
              {ISSUE_CATEGORIES.map((cat) => (
                <option key={cat.id} value={cat.id}>
                  {cat.label}
                </option>
              ))}
            </select>
          </div>

          {/* Municipal Department Filter */}
          <div className="space-y-1">
            <label className="block text-[10px] font-bold text-slate-600 dark:text-slate-400 uppercase">Routed Department</label>
            <select
              value={departmentFilter}
              onChange={(e) => setDepartmentFilter(e.target.value)}
              className="w-full px-3 py-2 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs text-slate-900 dark:text-white focus:outline-none focus:dark:border-blue-500 focus:dark:ring-1 focus:dark:ring-blue-500 transition-colors cursor-pointer"
            >
              <option value="all">All Departments</option>
              {MUNICIPAL_DEPARTMENTS.map((dept) => (
                <option key={dept} value={dept}>
                  {dept}
                </option>
              ))}
            </select>
          </div>
        </div>
      </div>

      {/* Dynamic Priority Queue Table */}
      <div className="rounded-2xl bg-white/80 border border-slate-200/80 shadow-sm dark:bg-slate-900/60 dark:backdrop-blur-xl dark:border dark:border-slate-800/80 dark:shadow-[0_8px_32px_0_rgba(0,0,0,0.37)] overflow-hidden transition-all duration-300">
        <div className="p-5 border-b border-slate-100 dark:border-slate-800/80 flex flex-wrap items-center justify-between gap-3">
          <div>
            <h3 className="text-base font-bold text-slate-900 dark:text-white tracking-wide">
              Municipal Priority Queue (Sorted by Urgency)
            </h3>
            <p className="text-xs text-slate-500 dark:text-slate-400 mt-0.5">
              Displaying {prioritySortedComplaints.length} tickets matching active filter parameters
            </p>
          </div>
          <span className="px-3 py-1 rounded-full bg-blue-100 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300 border border-blue-200 dark:border-blue-500/30 text-xs font-semibold">
            Auto-Prioritized by AI Vision
          </span>
        </div>

        {loading ? (
          <div className="p-8 text-center space-y-3">
            <Loader2 className="w-8 h-8 text-blue-600 dark:text-blue-400 animate-spin mx-auto" />
            <p className="text-xs font-medium text-slate-500 dark:text-slate-400">Loading municipal priority queue...</p>
          </div>
        ) : fetchError ? (
          <div className="p-8 text-center space-y-3 bg-amber-50/50 dark:bg-amber-950/20 border-y border-amber-200 dark:border-amber-900/50">
            <div className="w-10 h-10 rounded-2xl bg-amber-100 dark:bg-amber-900/40 text-amber-600 dark:text-amber-400 flex items-center justify-center mx-auto">
              <RefreshCw className="w-5 h-5" />
            </div>
            <h4 className="text-sm font-bold text-amber-900 dark:text-amber-300">Database Synchronization Notice</h4>
            <p className="text-xs text-amber-700 dark:text-amber-400 max-w-md mx-auto">{fetchError}</p>
            <Button onClick={fetchComplaintsDirectly} variant="outline" className="text-xs">
              <RefreshCw className="w-3.5 h-3.5 mr-1.5" /> Retry Sync
            </Button>
          </div>
        ) : prioritySortedComplaints.length === 0 ? (
          <div className="p-12 text-center space-y-3">
            <FileText className="w-8 h-8 text-slate-400 dark:text-slate-600 mx-auto" />
            <h4 className="text-sm font-bold text-slate-800 dark:text-slate-300">No Queue Tickets Match Criteria</h4>
            <p className="text-xs text-slate-500">Adjust your status, category, or search filters above.</p>
          </div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs text-slate-800 dark:text-slate-300">
              <thead className="bg-slate-50 dark:bg-slate-950/80 text-slate-700 dark:text-slate-400 font-bold uppercase tracking-wider text-[10px] border-b border-slate-200 dark:border-slate-800">
                <tr>
                  <th className="py-3.5 px-4">Urban Impact Score</th>
                  <th className="py-3.5 px-4">Urgency & Issue</th>
                  <th className="py-3.5 px-4">Category & Location</th>
                  <th className="py-3.5 px-4">Routed Department</th>
                  <th className="py-3.5 px-4">SLA Compliance</th>
                  <th className="py-3.5 px-4">Reporter & AI Diagnosis</th>
                  <th className="py-3.5 px-4">Upvotes</th>
                  <th className="py-3.5 px-4">Status</th>
                  <th className="py-3.5 px-4 text-right">Dispatch Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 dark:divide-slate-800/80">
                {prioritySortedComplaints.map((item) => {
                  const imageUrl = item.complaint_images?.[0]?.image_url || null;
                  const isUpdatingThis = updatingId === item.id;
                  const itemSeverity = item.severity || item.severity_score || 'Medium';
                  const impactInfo = calculateUrbanImpactScore(item, complaints);
                  const slaMetrics = slaService.getComplaintMetrics(item);

                  return (
                    <tr key={item.id} className="hover:bg-slate-50/80 dark:hover:bg-slate-800/40 transition-colors">
                      {/* Urban Impact Score Column */}
                      <td className="py-4 px-4 relative">
                        <div className="flex flex-col items-start space-y-1">
                          <div className="flex items-center gap-1.5">
                            <span className={`px-2.5 py-1 rounded-xl text-xs font-extrabold border shadow-2xs flex items-center gap-1 ${impactInfo.colorClass}`}>
                              ⚡ {impactInfo.score} / 100
                            </span>
                            <button
                              type="button"
                              onClick={() => setActiveTooltipId(activeTooltipId === item.id ? null : item.id)}
                              onMouseEnter={() => setActiveTooltipId(item.id)}
                              className="text-slate-400 hover:text-blue-600 dark:hover:text-blue-400 cursor-pointer p-0.5"
                              title="Why this score?"
                            >
                              <HelpCircle className="w-3.5 h-3.5" />
                            </button>
                          </div>
                          <span className="text-[10px] font-bold uppercase tracking-wider text-slate-500 dark:text-slate-400">
                            {impactInfo.category}
                          </span>

                          {/* Expandable Explanation Tooltip */}
                          {activeTooltipId === item.id && (
                            <div className="absolute left-4 top-14 z-50 w-64 p-3 rounded-2xl bg-slate-900 text-white shadow-xl border border-slate-700 text-xs space-y-2 animate-in fade-in zoom-in-95">
                              <div className="flex items-center justify-between border-b border-slate-800 pb-1.5 font-bold">
                                <span className="text-blue-400">Why this score?</span>
                                <span>{impactInfo.score} pts</span>
                              </div>
                              <div className="space-y-1 text-[11px] font-mono text-slate-300">
                                <div className="flex justify-between">
                                  <span>Severity rating:</span>
                                  <strong className="text-amber-400">+{impactInfo.breakdown.severity}</strong>
                                </div>
                                <div className="flex justify-between">
                                  <span>Community support:</span>
                                  <strong className="text-amber-400">+{impactInfo.breakdown.community}</strong>
                                </div>
                                <div className="flex justify-between">
                                  <span>Nearby concentration:</span>
                                  <strong className="text-amber-400">+{impactInfo.breakdown.concentration}</strong>
                                </div>
                                <div className="flex justify-between">
                                  <span>Unresolved persistence:</span>
                                  <strong className="text-amber-400">+{impactInfo.breakdown.persistence}</strong>
                                </div>
                              </div>
                              <div className="pt-1.5 border-t border-slate-800 text-[10px] text-slate-400 flex items-center justify-between font-sans">
                                <span>Urban Impact Matrix</span>
                                <span className="font-bold text-white">{impactInfo.category}</span>
                              </div>
                            </div>
                          )}
                        </div>
                      </td>

                      {/* Urgency & Issue Summary */}
                      <td className="py-4 px-4">
                        <div className="flex items-start gap-3">
                          <div className="w-14 h-14 rounded-xl bg-slate-100 dark:bg-slate-950 border border-slate-200 dark:border-slate-800 overflow-hidden shrink-0 flex items-center justify-center">
                            {imageUrl ? (
                              <img src={imageUrl} alt={item.title} className="w-full h-full object-cover" />
                            ) : (
                              <Layers className="w-5 h-5 text-slate-400 dark:text-slate-600" />
                            )}
                          </div>
                          <div className="space-y-1">
                            <span className={`px-2 py-0.5 rounded-full text-[9px] font-bold uppercase border ${getSeverityBadgeColor(itemSeverity)}`}>
                              {itemSeverity}
                            </span>
                            <h4 className="font-bold text-slate-900 dark:text-white text-sm leading-snug line-clamp-1">{item.title}</h4>
                            <p className="text-slate-500 dark:text-slate-400 text-[11px] line-clamp-1">{item.description}</p>
                          </div>
                        </div>
                      </td>

                      {/* Category & Location */}
                      <td className="py-4 px-4 space-y-1">
                        <div className="flex items-center gap-1 font-semibold text-blue-600 dark:text-blue-400 capitalize">
                          <Tag className="w-3.5 h-3.5" />
                          <span>{item.category || 'General'}</span>
                        </div>
                        <div className="flex items-center gap-1 text-slate-600 dark:text-slate-400 truncate max-w-[180px]">
                          <MapPin className="w-3.5 h-3.5 text-red-500 shrink-0" />
                          <span className="truncate">{item.address || 'GPS Tagged'}</span>
                        </div>
                      </td>

                      {/* Recommended Department & Reassign Route Dropdown */}
                      <td className="py-4 px-4 space-y-1">
                        <div className="flex items-center gap-1.5 font-bold text-slate-900 dark:text-white text-xs">
                          <Building2 className="w-3.5 h-3.5 text-indigo-600 dark:text-indigo-400 shrink-0" />
                          <span className="truncate">
                            {item.recommended_department || getRecommendedDepartment(item.category)}
                          </span>
                        </div>
                        <div className="flex items-center justify-between gap-1 text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          <span>AI-Assisted</span>
                          <select
                            value={item.recommended_department || getRecommendedDepartment(item.category)}
                            onChange={(e) => handleDepartmentChange(item.id, e.target.value)}
                            className="text-[10px] bg-transparent border-b border-slate-300 dark:border-slate-700 text-blue-600 dark:text-blue-400 font-bold focus:outline-none cursor-pointer"
                            title="Reassign or confirm routed department"
                          >
                            {MUNICIPAL_DEPARTMENTS.map((dept) => (
                              <option key={dept} value={dept} className="bg-slate-900 text-white">
                                {dept}
                              </option>
                            ))}
                          </select>
                        </div>
                      </td>

                      {/* SLA Compliance Status */}
                      <td className="py-4 px-4 space-y-1">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase inline-flex items-center gap-1 ${
                          slaMetrics.isSlaBreached
                            ? 'bg-rose-100 dark:bg-rose-500/10 text-rose-800 dark:text-rose-400 border border-rose-200 dark:border-rose-500/30'
                            : 'bg-emerald-100 dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30'
                        }`}>
                          {slaMetrics.isSlaBreached ? <AlertTriangle className="w-3 h-3 text-rose-500 animate-pulse" /> : <CheckCircle2 className="w-3 h-3 text-emerald-500" />}
                          {slaMetrics.slaStatusLabel}
                        </span>
                        <div className="text-[10px] text-slate-500 dark:text-slate-400 font-mono">
                          Threshold: {slaMetrics.thresholdHours}h Limit
                        </div>
                      </td>

                      {/* Reporter & AI Diagnosis */}
                      <td className="py-4 px-4 space-y-1">
                        <div className="flex items-center gap-1 font-mono text-slate-700 dark:text-slate-300">
                          <User className="w-3 h-3 text-slate-400" />
                          <span>{item.profiles?.email || 'Citizen Report'}</span>
                        </div>
                        <div className="flex items-center gap-1 text-[10px] text-indigo-700 dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/60 px-2 py-0.5 rounded border border-indigo-200 dark:border-indigo-900/60 max-w-[220px]">
                          <Sparkles className="w-3 h-3 text-indigo-500 dark:text-indigo-400 shrink-0" />
                          <span className="truncate">{item.ai_summary || 'Gemini Vision Analyzed'}</span>
                        </div>
                      </td>

                      {/* Upvotes Count */}
                      <td className="py-4 px-4">
                        <span className="px-2.5 py-1 rounded-lg bg-slate-100 dark:bg-slate-800 text-slate-800 dark:text-amber-300 font-bold border border-slate-200 dark:border-slate-700">
                          👍 {item.upvotes || 1}
                        </span>
                      </td>

                      {/* Current Status Badge */}
                      <td className="py-4 px-4">
                        <span className={`px-2.5 py-1 rounded-lg text-[10px] font-bold uppercase ${
                          (item.status || '').toLowerCase() === 'resolved'
                            ? 'bg-emerald-100 dark:bg-emerald-500/10 text-emerald-800 dark:text-emerald-400 border border-emerald-200 dark:border-emerald-500/30'
                            : (item.status || '').toLowerCase() === 'in progress'
                            ? 'bg-indigo-100 dark:bg-indigo-950 text-indigo-800 dark:text-indigo-300 border border-indigo-200 dark:border-indigo-800'
                            : 'bg-amber-100 dark:bg-amber-950 text-amber-800 dark:text-amber-300 border border-amber-200 dark:border-amber-800'
                        }`}>
                          {item.status || 'Pending'}
                        </span>
                      </td>

                      {/* Interactive Status Dropdown & Delete Action */}
                      <td className="py-4 px-4 text-right">
                        <div className="flex items-center justify-end gap-2">
                          {isUpdatingThis ? (
                            <div className="inline-flex items-center gap-1.5 px-3 py-1.5 bg-slate-100 dark:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 font-medium">
                              <Loader2 className="w-3.5 h-3.5 animate-spin text-blue-600 dark:text-blue-400" />
                              Updating...
                            </div>
                          ) : (
                            <select
                              value={item.status || 'Pending'}
                              onChange={(e) => handleStatusChange(item.id, e.target.value)}
                              className="px-3 py-1.5 bg-slate-50 dark:bg-slate-800/50 border border-slate-200 dark:border-slate-700/80 rounded-xl text-xs font-semibold text-slate-900 dark:text-white focus:outline-none focus:dark:border-blue-500 focus:dark:ring-1 focus:dark:ring-blue-500 transition-colors cursor-pointer"
                            >
                              <option value="Pending">⚡ Pending</option>
                              <option value="In Progress">🛠️ In Progress</option>
                              <option value="Resolved">✅ Resolved</option>
                            </select>
                          )}

                          <button
                            type="button"
                            onClick={() => handleAdminDelete(item.id)}
                            className="p-1.5 rounded-xl bg-slate-100 dark:bg-slate-800/60 hover:bg-rose-500/20 text-slate-500 hover:text-rose-500 dark:text-slate-400 dark:hover:text-rose-400 border border-slate-200 dark:border-slate-700/80 transition-colors cursor-pointer"
                            title="Delete / Dismiss Ticket"
                            aria-label="Delete or dismiss complaint"
                          >
                            <Trash2 className="w-4 h-4" />
                          </button>
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {/* Hotspot Full Intelligence Details & Related Issues Modal */}
      {selectedHotspot && (
        <HotspotDetailsModal
          hotspot={selectedHotspot}
          onClose={() => setSelectedHotspot(null)}
          onUpdateStatus={updateHotspotStatus}
          onUpdateDepartment={updateHotspotDepartment}
          onSelectComplaint={(complaint) => {
            setSelectedHotspot(null);
            if (complaint?.title) {
              setSearchQuery(complaint.title);
            }
          }}
        />
      )}
    </div>
  );
}

